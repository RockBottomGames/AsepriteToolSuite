# Base Tools

* Should be copied into each sub project folder before zipping if you would like to run individual sub projects.
  * This should be done already but if you see issues you can try moving these files over.